from django.apps import AppConfig


class GoogleappConfig(AppConfig):
    name = 'googleapp'
